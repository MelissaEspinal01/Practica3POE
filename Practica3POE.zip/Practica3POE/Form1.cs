namespace Practica3POE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Buscar_Click(object sender, EventArgs e)
        {
            //Utilizar la clase OpenFileDialog para visualizar la ventana

            OpenFileDialog abrir = new OpenFileDialog();

            //Filtrar para abrir imagenes jpg

            abrir.Filter = "JPEG (*, JPG) |* JPG";

            //Verificar ventana y mostrarla
            //ShowDialog abre un ventana, el if valida nuestra respuesta

            if (abrir.ShowDialog() == DialogResult.OK) 
            {
                //Validaciones sobre ventana img
                pictureBox1.Image = Image.FromFile(abrir.FileName);

            }
            else
            {

            }
        }

        private bool islag = true;

        private void Cambiar_Click(object sender, EventArgs e)
        {
            if(islag)
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\MINEDUCYT\\source\\repos\\Practica3POE\\Imagenes\\gatita.jpeg");
                islag= false;
            }else
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\MINEDUCYT\\source\\repos\\Practica3POE\\Imagenes\\pan.png");
                islag= true;
            }
        }


        private void imageTimer_Tick(object sender, EventArgs e)
        {
            if (islag)
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\MINEDUCYT\\source\\repos\\Practica3POE\\Imagenes\\gatita.jpeg");
                islag = false;
            }
            else
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\MINEDUCYT\\source\\repos\\Practica3POE\\Imagenes\\pan.png");
                islag = true;
            }
        }
    }
}